package com.exemplo.painelyaris

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

// ---------- Mostrador circular ----------
class GaugeView(ctx: Context, private val label: String, private val unit: String,
                private val max: Float, private val redFrom: Float) : View(ctx) {
    var value: Float = 0f
        set(v) { field = v; invalidate() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#26FFFFFF") }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8FA3B8"); textAlign = Paint.Align.CENTER }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h); val st = s * 0.075f
        track.strokeWidth = st; arc.strokeWidth = st
        val r = RectF(w / 2 - s / 2 + st, h / 2 - s / 2 + st, w / 2 + s / 2 - st, h / 2 + s / 2 - st)
        c.drawArc(r, 150f, 240f, false, track)
        tick.strokeWidth = s * 0.008f
        for (k in 0..20) {
            val a = Math.toRadians(150.0 + 240.0 * k / 20)
            val r1 = s / 2 - st * 2.3f
            val r2 = r1 - (if (k % 5 == 0) s * 0.05f else s * 0.025f)
            tick.color = if (k / 20f * max >= redFrom) Color.parseColor("#FF1744") else Color.parseColor("#66FFFFFF")
            c.drawLine(w / 2 + (r1 * Math.cos(a)).toFloat(), h / 2 + (r1 * Math.sin(a)).toFloat(),
                w / 2 + (r2 * Math.cos(a)).toFloat(), h / 2 + (r2 * Math.sin(a)).toFloat(), tick)
        }
        if (value >= redFrom) { arc.shader = null; arc.color = Color.parseColor("#FF1744") }
        else arc.shader = LinearGradient(0f, h, 0f, 0f, Color.parseColor("#00E5FF"), Color.parseColor("#B388FF"), Shader.TileMode.CLAMP)
        val f = (value / max).coerceIn(0f, 1f)
        if (f > 0.005f) c.drawArc(r, 150f, 240f * f, false, arc)
        txt.textSize = s * 0.26f
        c.drawText(value.toInt().toString(), w / 2, h / 2 + s * 0.09f, txt)
        sub.textSize = s * 0.075f
        c.drawText(label, w / 2, h / 2 - s * 0.2f, sub)
        c.drawText(unit, w / 2, h / 2 + s * 0.21f, sub)
    }
}

class MainActivity : Activity() {

    // Se o multimídia tem um app de Bluetooth próprio, coloque o package aqui.
    private lateinit var prefs: android.content.SharedPreferences
    private val btPkg get() = prefs.getString("btPkg", "") ?: ""
    private val elmName get() = prefs.getString("elm", "") ?: ""
    private var useBt: Boolean
        get() = prefs.getBoolean("useBt", false)
        set(v) { prefs.edit().putBoolean("useBt", v).apply() }
    // Troque para true se quiser que a música local comece sozinha ao abrir.
    private val autoPlay get() = prefs.getBoolean("auto", false)

    data class Pid(val id: String, val name: String, val unit: String, val n: Int, val dec: Int, val f: (List<Int>) -> Double)

    private val pids = listOf(
        Pid("04", "Carga do motor", "%", 1, 0) { it[0] * 100.0 / 255 },
        Pid("05", "Água", "°C", 1, 0) { it[0] - 40.0 },
        Pid("06", "Correção curta", "%", 1, 1) { (it[0] - 128) * 100.0 / 128 },
        Pid("07", "Correção longa", "%", 1, 1) { (it[0] - 128) * 100.0 / 128 },
        Pid("0B", "Pressão MAP", "kPa", 1, 0) { it[0].toDouble() },
        Pid("0E", "Avanço", "°", 1, 1) { it[0] / 2.0 - 64 },
        Pid("0F", "Ar admissão", "°C", 1, 0) { it[0] - 40.0 },
        Pid("10", "Fluxo de ar", "g/s", 2, 1) { (it[0] * 256 + it[1]) / 100.0 },
        Pid("11", "Acelerador", "%", 1, 0) { it[0] * 100.0 / 255 },
        Pid("1F", "Tempo ligado", "s", 2, 0) { (it[0] * 256 + it[1]).toDouble() },
        Pid("2F", "Combustível", "%", 1, 0) { it[0] * 100.0 / 255 },
        Pid("33", "Pressão atm.", "kPa", 1, 0) { it[0].toDouble() },
        Pid("42", "Bateria", "V", 2, 1) { (it[0] * 256 + it[1]) / 1000.0 },
        Pid("44", "Lambda", "λ", 2, 2) { (it[0] * 256 + it[1]) / 32768.0 },
        Pid("46", "Ambiente", "°C", 1, 0) { it[0] - 40.0 },
        Pid("5C", "Óleo", "°C", 1, 0) { it[0] - 40.0 },
        Pid("5E", "Consumo", "L/h", 2, 1) { (it[0] * 256 + it[1]) / 20.0 }
    )

    private val SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private lateinit var rpmG: GaugeView
    private lateinit var spdG: GaugeView
    private lateinit var grid: GridLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvTrack: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnSrc: Button
    private val tiles = HashMap<String, TextView>()
    @Volatile private var running = false
    @Volatile private var wantDtc = false
    @Volatile private var reconnect = false
    @Volatile private var isCan = true
    @Volatile private var hasKm = false
    private var lastMaf = 0.0
    private var lastLh: Double? = null
    private var lastSpeed = 0.0

    // música
    private var player: MediaPlayer? = null
    private val tracks = ArrayList<Pair<Uri, String>>()
    private var idx = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        prefs = getSharedPreferences("painel", MODE_PRIVATE)
        buildUi()
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
        else loadTracks()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        loadTracks()
    }

    override fun onResume() { super.onResume(); startReading() }
    override fun onPause() { running = false; super.onPause() }
    override fun onDestroy() { player?.release(); super.onDestroy() }

    // ---------- Interface ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: String, r: Int) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat() }

    private fun btn(t: String, w: Int, cb: () -> Unit) = Button(this).apply {
        text = t; textSize = 16f; setTextColor(Color.WHITE); setAllCaps(false)
        background = bg("#1D2433", 14)
        setOnClickListener { cb() }
        layoutParams = LinearLayout.LayoutParams(dp(w), dp(56)).apply { setMargins(dp(4), 0, dp(4), 0) }
    }

    private fun accent(id: String) = when (id) {
        "05", "0F", "46", "5C" -> "#FF9100"
        "42" -> "#FFEA00"
        "2F", "KM", "5E", "10" -> "#00E676"
        "06", "07", "44" -> "#B388FF"
        else -> "#00E5FF"
    }

    private fun addTile(id: String, name: String, unit: String) {
        val v = TextView(this).apply {
            text = "--"; textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); gravity = Gravity.CENTER }
        val l = TextView(this).apply {
            text = "$name · $unit"; textSize = 13f; setTextColor(Color.parseColor("#8FA3B8")); gravity = Gravity.CENTER }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = bg("#161B26", 16); setPadding(dp(6), dp(10), dp(6), dp(10))
            addView(View(context).apply { background = bg(accent(id), 2) },
                LinearLayout.LayoutParams(dp(36), dp(3)).apply { bottomMargin = dp(6) })
            addView(l); addView(v)
        }
        val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            .apply { width = 0; setMargins(dp(5), dp(5), dp(5), dp(5)) }
        grid.addView(box, lp)
        tiles[id] = v
    }

    private fun buildTiles(list: List<Pid>, withKm: Boolean) {
        grid.removeAllViews(); tiles.clear()
        list.forEach { addTile(it.id, it.name, it.unit) }
        if (withKm) addTile("KM", "Consumo (est.)", "km/l")
        hasKm = withKm
    }

    private fun buildUi() {
        rpmG = GaugeView(this, "RPM", "rpm", 7000f, 6200f)
        spdG = GaugeView(this, "VELOCIDADE", "km/h", 200f, 9999f)
        grid = GridLayout(this).apply { columnCount = 3 }
        tvStatus = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#8FA3B8")); text = "Desconectado" }
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 34f; setTextColor(Color.WHITE) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
            addView(clock, LinearLayout.LayoutParams(0, -2, 1f)); addView(tvStatus)
        }
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(header)
            addView(ScrollView(context).apply { addView(grid) }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(rpmG, LinearLayout.LayoutParams(0, -1, 1f))
            addView(center, LinearLayout.LayoutParams(0, -1, 1.3f))
            addView(spdG, LinearLayout.LayoutParams(0, -1, 1f))
        }
        tvTrack = TextView(this).apply {
            text = "Sem músicas locais — os botões controlam o app de música"
            textSize = 16f; setTextColor(Color.WHITE); setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MARQUEE; setMarqueeRepeatLimit(-1); isSelected = true
        }
        btnPlay = btn("►", 70) { togglePlay() }.apply { background = bg("#00B8D4", 28) }
        btnSrc = btn(if (useBt) "Fonte: BT" else "Fonte: Local", 120) { toggleSrc() }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bg("#0F1320", 0); setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(btn("Áudio BT", 100) { openBluetooth() })
            addView(btnSrc)
            addView(btn("Ajustes", 90) { showSettings() })
            addView(tvTrack, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(14), 0, dp(14), 0) })
            addView(btn("◄◄", 70) { step(-1) }); addView(btnPlay); addView(btn("►►", 70) { step(1) })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0E1424"), Color.parseColor("#04060B")))
            addView(top, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bar, LinearLayout.LayoutParams(-1, -2))
        })
    }

    private fun openBluetooth() {
        val launch = if (btPkg.isNotEmpty()) packageManager.getLaunchIntentForPackage(btPkg) else null
        startActivity(launch ?: Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    // ---------- Ajustes ----------
    private fun toggleSrc() {
        useBt = !useBt
        if (useBt) { player?.pause(); btnPlay.text = "►" }
        btnSrc.text = if (useBt) "Fonte: BT" else "Fonte: Local"
        tvTrack.text = if (useBt) "Música Bluetooth — os botões controlam o celular"
            else if (tracks.isEmpty()) "Sem músicas locais" else "${tracks.size} músicas — toque em ►"
    }

    private fun showSettings() {
        val items = arrayOf("Ler códigos de falha", "App de áudio Bluetooth do multimídia",
            "Adaptador OBD (ELM327)", "Tocar música local ao abrir: " + (if (autoPlay) "SIM" else "NÃO"),
            "Ajustes do Android")
        AlertDialog.Builder(this).setTitle("Ajustes").setItems(items) { _, w ->
            when (w) {
                0 -> { setStatus("Lendo falhas..."); wantDtc = true }
                1 -> pickApp()
                2 -> pickElm()
                3 -> prefs.edit().putBoolean("auto", !autoPlay).apply()
                4 -> startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }.show()
    }

    private fun pickApp() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = arrayOf("(nenhum — abrir Bluetooth do Android)") + apps.map { it.loadLabel(pm).toString() }
        AlertDialog.Builder(this).setTitle("Qual app toca o Bluetooth?").setItems(names) { _, w ->
            prefs.edit().putString("btPkg", if (w == 0) "" else apps[w - 1].activityInfo.packageName).apply()
        }.show()
    }

    private fun pickElm() {
        val devs = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList() }
            catch (e: Exception) { emptyList() }
        val names = arrayOf("(automático)") + devs.map { it.name ?: it.address }
        AlertDialog.Builder(this).setTitle("Adaptador OBD").setItems(names) { _, w ->
            prefs.edit().putString("elm", if (w == 0) "" else (devs[w - 1].name ?: "")).apply()
            reconnect = true
        }.show()
    }

    // ---------- Música ----------
    private fun loadTracks() {
        tracks.clear()
        try {
            val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE)?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                    tracks.add(Pair(uri, (c.getString(1) ?: "?") + " — " + (c.getString(2) ?: "")))
                }
            }
        } catch (e: Exception) { }
        if (tracks.isNotEmpty()) {
            tvTrack.text = "${tracks.size} músicas encontradas — toque em ► para tocar"
            if (autoPlay && player == null && !useBt) playTrack(0)
        }
    }

    private fun playTrack(i: Int) {
        if (tracks.isEmpty()) return
        idx = (i + tracks.size) % tracks.size
        try {
            player?.release()
            player = MediaPlayer().apply {
                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(this@MainActivity, tracks[idx].first)
                setOnCompletionListener { playTrack(idx + 1) }
                prepare(); start()
            }
            tvTrack.text = tracks[idx].second; btnPlay.text = "❚❚"
        } catch (e: Exception) { tvTrack.text = "Erro ao tocar essa música"; playTrackLater() }
    }

    private fun playTrackLater() { btnPlay.text = "►"; player = null }

    private fun togglePlay() {
        if (tracks.isEmpty() || useBt) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        val p = player
        if (p == null) playTrack(idx)
        else if (p.isPlaying) { p.pause(); btnPlay.text = "►" }
        else { p.start(); btnPlay.text = "❚❚" }
    }

    private fun step(d: Int) {
        if (tracks.isEmpty() || useBt) mediaKey(if (d > 0) KeyEvent.KEYCODE_MEDIA_NEXT else KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        else playTrack(idx + d)
    }

    // Sem músicas locais: controla o app que estiver tocando (Spotify, Bluetooth etc.)
    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---------- OBD2 via ELM327 ----------
    private fun ui(b: () -> Unit) = runOnUiThread { b() }
    private fun setStatus(s: String) = ui { tvStatus.text = s }

    private fun startReading() {
        if (running) return
        running = true
        Thread {
            var socket: BluetoothSocket? = null
            var sup: List<Pid> = emptyList()
            var rot = 0
            while (running) {
                try {
                    if (reconnect) { reconnect = false; try { socket?.close() } catch (_: Exception) { }; socket = null }
                    if (socket == null || !socket.isConnected) {
                        setStatus("Conectando...")
                        val s = connect()
                        if (s == null) { setStatus("ELM327 não encontrado (pareie primeiro)"); Thread.sleep(3000); continue }
                        socket = s
                        val o = s.outputStream; val i = s.inputStream
                        for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) send(o, i, c)
                        send(o, i, "0100")
                        isCan = send(o, i, "ATDPN").lastOrNull()?.let { it in '6'..'9' } ?: true
                        val ids = supported(o, i)
                        sup = pids.filter { it.id in ids }
                        if (ids.isEmpty()) {
                            setStatus("Sem resposta do carro (ligue a ignição)")
                            s.close(); socket = null; Thread.sleep(3000); continue
                        }
                        val withKm = "10" in ids
                        ui { buildTiles(sup, withKm) }
                        setStatus("Conectado · ${ids.size} sensores")
                    }
                    val s = socket ?: continue
                    val o = s.outputStream; val i = s.inputStream
                    if (wantDtc) { wantDtc = false; readDtc(o, i); setStatus("Conectado") }

                    query(o, i, "0C", 2)?.let { b -> ui { rpmG.value = (b[0] * 256 + b[1]) / 4f } }
                    query(o, i, "0D", 1)?.let { b -> lastSpeed = b[0].toDouble(); ui { spdG.value = b[0].toFloat() } }
                    if (sup.isNotEmpty()) repeat(3) { readPid(o, i, sup[rot++ % sup.size]) }

                    if (hasKm) {
                        val lh = lastLh ?: (lastMaf * 0.3429)   // estimativa p/ gasolina
                        val t = if (lastSpeed > 3 && lh > 0.1) "%.1f".format(lastSpeed / lh) else "--"
                        ui { tiles["KM"]?.text = t }
                    }
                } catch (e: Exception) {
                    try { socket?.close() } catch (_: Exception) { }
                    socket = null
                    setStatus("Reconectando...")
                    Thread.sleep(2000)
                }
            }
            try { socket?.close() } catch (_: Exception) { }
        }.start()
    }

    private fun connect(): BluetoothSocket? {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return null
        val dev = adapter.bondedDevices.firstOrNull {
            val n = (it.name ?: "").uppercase()
            if (elmName.isNotEmpty()) it.name == elmName
            else n.contains("OBD") || n.contains("ELM") || n.contains("VLINK") || n.contains("VGATE")
        } ?: return null
        adapter.cancelDiscovery()
        return dev.createRfcommSocketToServiceRecord(SPP).also { it.connect() }
    }

    private fun readPid(o: OutputStream, i: InputStream, p: Pid) {
        val b = query(o, i, p.id, p.n) ?: return
        val v = p.f(b)
        if (p.id == "10") lastMaf = v
        if (p.id == "5E") lastLh = v
        val t = "%.${p.dec}f".format(v)
        ui { tiles[p.id]?.text = t }
    }

    private fun supported(o: OutputStream, i: InputStream): Set<String> {
        val set = HashSet<String>()
        var base = 0
        for (q in listOf("00", "20", "40")) {
            val b = bytes(send(o, i, "01$q"), "41$q", 4) ?: break
            val mask = b.fold(0L) { acc, x -> acc * 256 + x }
            for (k in 0 until 32) if ((mask and (1L shl (31 - k))) != 0L) set.add("%02X".format(base + k + 1))
            if ((mask and 1L) == 0L) break
            base += 32
        }
        return set
    }

    private fun readDtc(o: OutputStream, i: InputStream) {
        val mil = bytes(send(o, i, "0101"), "4101", 4)
        val codes = parseDtc(raw(o, i, "03"))
        val head = if (mil == null) "" else if (mil[0] >= 128) "Luz de injeção: ACESA\n\n" else "Luz de injeção: apagada\n\n"
        val msg = head + (if (codes.isEmpty()) "Nenhum código de falha." else codes.joinToString("\n"))
        ui { AlertDialog.Builder(this).setTitle("Códigos de falha").setMessage(msg).setPositiveButton("OK", null).show() }
    }

    private fun parseDtc(raw: String): List<String> {
        val sb = StringBuilder()
        for (line in raw.split("\r", "\n")) {
            var l = line.replace(" ", "").uppercase()
            if (l.isEmpty() || l.any { it !in "0123456789ABCDEF:" }) continue
            l = l.replace(Regex("^[0-9A-F]:"), "")
            if (l.length == 3) continue
            sb.append(l)
        }
        var r = sb.toString()
        val k = r.indexOf("43")
        if (k < 0) return emptyList()
        r = r.substring(k + 2)
        var max = 99
        if (isCan) {
            if (r.length < 2) return emptyList()
            max = r.substring(0, 2).toIntOrNull(16) ?: 0
            r = r.substring(2)
        }
        val out = ArrayList<String>()
        var p = 0
        while (p + 4 <= r.length && out.size < max) {
            val w = r.substring(p, p + 4); p += 4
            if (w == "0000") continue
            val v = w.toIntOrNull(16) ?: break
            out.add("" + "PCBU"[v shr 14] + ((v shr 12) and 3) + "%03X".format(v and 0xFFF))
        }
        return out
    }

    private fun query(o: OutputStream, i: InputStream, id: String, n: Int) = bytes(send(o, i, "01$id"), "41$id", n)

    private fun raw(out: OutputStream, inp: InputStream, cmd: String): String {
        while (inp.available() > 0) inp.read()
        out.write((cmd + "\r").toByteArray()); out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val ch = inp.read().toChar()
                if (ch == '>') break
                sb.append(ch)
            } else Thread.sleep(8)
        }
        return sb.toString()
    }

    private fun send(out: OutputStream, inp: InputStream, cmd: String) =
        raw(out, inp, cmd).replace("\r", "").replace("\n", "").replace(" ", "")

    private fun bytes(resp: String, header: String, n: Int): List<Int>? {
        val i = resp.indexOf(header)
        if (i < 0 || resp.length < i + header.length + n * 2) return null
        return try {
            (0 until n).map { resp.substring(i + header.length + it * 2, i + header.length + it * 2 + 2).toInt(16) }
        } catch (e: Exception) { null }
    }
}
